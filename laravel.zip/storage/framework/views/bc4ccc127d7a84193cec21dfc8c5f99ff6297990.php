<?php $__env->startSection('admin'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

<div class="page-content">


				<div class="row">
					<div class="col-md-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h6 class="card-title">All User </h6>

                <div class="table-responsive">
                  <table id="dataTableExample" class="table">
                    <thead>
                      <tr>
                        <th>Sl </th>
                        <th>Image </th>
                        <th>Name </th>
                        <th>Role </th>
                        <th>Phone Number </th>
                        <th>Action </th>
                      </tr>
                    </thead>
                    <tbody>
                   <?php $__currentLoopData = $alluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><img src="<?php echo e((!empty($item->photo)) ? url('upload/agent_images/'.$item->photo) : url('upload/no_image.jpg')); ?>" style="width:60px; height:60px;"> </td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->role); ?></td>
                        <th><?php echo e($item->phone); ?></th>


                        <td>


       <a href="<?php echo e(route('edit.user',$item->id)); ?>" class="btn btn-inverse-warning" title="Edit"> <i data-feather="edit"></i> </a>

       <a href="<?php echo e(route('delete.user',$item->id)); ?>" class="btn btn-inverse-danger" id="delete" title="Delete"> <i data-feather="trash-2"></i>  </a>
                        </td>
                      </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
					</div>
				</div>

			</div>

            <script type="text/javascript">
                $(function() {
                    $('.toggle-class').change(function() {
                        var status = $(this).prop('checked') == true ? 1 : 0;
                        var user_id = $(this).data('id');

                        $.ajax({
                            type: "GET",
                            dataType: "json",
                            url: '/changeStatus',
                            data: {'status': status, 'user_id': user_id},
                            success: function(data){
                    if ($.isEmptyObject(data.error)) {
                        // Success notification
                        toastr.success(data.success, 'Success');
                    } else {
                        // Error notification
                        toastr.error(data.error, 'Error');
                    }

                    // Refresh the page after 3 seconds
                    setTimeout(function() {
                        location.reload();
                    }, 500);
                }
            });
        });
    });
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/backend/user/all_user.blade.php ENDPATH**/ ?>