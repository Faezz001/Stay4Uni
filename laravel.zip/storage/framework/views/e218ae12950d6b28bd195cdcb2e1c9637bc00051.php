<?php $__env->startSection('main'); ?>


    <!--Page Title-->
        <section class="page-title-two bg-color-1 centred">
            <div class="pattern-layer">
                <div class="pattern-1" style="background-image: url(<?php echo e(asset('frontend/assets/images/shape/shape-9.png')); ?>);"></div>
                <div class="pattern-2" style="background-image: url(<?php echo e(asset('frontend/assets/images/shape/shape-10.png')); ?>);"></div>
            </div>
            <div class="auto-container">
                <div class="content-box clearfix">
                    <h1>WishList Property </h1>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.html">Home</a></li>
                        <li>WishList Property</li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Page Title-->


        <!-- property-page-section -->
        <section class="property-page-section property-list">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">

        <?php
            $id = Auth::user()->id;
            $userData = App\Models\User::find($id);
        ?>


   <div class="blog-sidebar">
  <div class="sidebar-widget post-widget">
                    <div class="widget-title">
                        <h4>User Profile </h4>
                    </div>
                       <div class="post-inner">
                        <div class="post">
                            <figure class="post-thumb"><a href="blog-details.html">
        <img src="<?php echo e((!empty($userData->photo)) ? url('upload/user_images/'.$userData->photo) : url('upload/no_image.jpg')); ?>" alt=""></a></figure>
        <h5><a href="blog-details.html"><?php echo e($userData->name); ?> </a></h5>
         <p><?php echo e($userData->email); ?> </p>
                        </div>
                    </div>
                </div>


<div class="sidebar-widget category-widget">
            <div class="widget-title">

            </div>
             <?php echo $__env->make('frontend.dashboard.dashboard_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


          </div>
</div>






                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                        <div class="property-content-side">

                            <div class="wrapper list">
                                <div class="deals-list-content list-item">

                                    <div id="wishlist">
                                    </div>
                    </div>
            </div>
                        </div>
                    </div>
        </section>
        <!-- property-page-section end -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/frontend/dashboard/wishlist.blade.php ENDPATH**/ ?>