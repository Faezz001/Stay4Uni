
<?php $__env->startSection('main'); ?>

<!-- banner-section -->

<!-- banner-section end -->
<?php echo $__env->make('frontend.home.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- category-section -->
<?php echo $__env->make('frontend.home.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- category-section end -->


<!-- feature-section -->
<?php echo $__env->make('frontend.home.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- feature-section end -->


<!-- video-section -->

<!-- video-section end -->


<!-- deals-section -->

<!-- deals-section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/frontend/index.blade.php ENDPATH**/ ?>