<?php
$ptype = App\Models\PropertyType::latest()->limit(5)->get();
?>



<?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/frontend/home/category.blade.php ENDPATH**/ ?>