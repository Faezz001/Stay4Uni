<?php $__env->startSection('agent'); ?>



<div class="page-content">

    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
<a href="<?php echo e(route('agent.add.property')); ?>" class="btn btn-inverse-info"> Add Property</a>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
<div class="card">
  <div class="card-body">
    <h6 class="card-title">Property All </h6>

    <div class="table-responsive">
      <table id="dataTableExample" class="table">
        <thead>
          <tr>
            <th>No </th>
            <th>Property Name </th>
            <th>Property Type </th>
            <th>Status Type </th>
            <th>Rental Price </th>
            <th>Address</th>
            <th>City</th>
            <th>State</th>
            <th>Zipcode</th>
            <th>Action </th>
          </tr>
        </thead>
        <tbody>
       <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($item->property_name); ?></td>
            <td><?php echo e($item['type']['type_name']); ?></td>
            <td><?php echo e($item->property_status); ?></td>
            <td><?php echo e($item->rental_price); ?></td>
            <td><?php echo e($item->address); ?></td>
            <td><?php echo e($item->city); ?></td>
            <td><?php echo e($item->state); ?></td>
            <td><?php echo e($item->zip); ?></td>
            <td>
<a href="<?php echo e(route('agent.edit.property',$item->id)); ?>" class="btn btn-inverse-warning" title="Edit"> <i data-feather="edit"></i> </a>
<a href="<?php echo e(route('agent.delete.property',$item->id)); ?>" class="btn btn-inverse-danger" id="delete" title="Delete"> <i data-feather="trash-2"></i> </a>
            </td>
          </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.agent_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/agent/property/all_property.blade.php ENDPATH**/ ?>