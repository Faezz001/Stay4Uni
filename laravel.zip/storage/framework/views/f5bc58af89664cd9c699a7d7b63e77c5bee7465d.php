<section class="banner-section" style="background-image: url(<?php echo e(asset('frontend/assets/images/banner/banner-1.jpg')); ?>);">
    <div class="auto-container">
        <div class="inner-container">
            <div class="content-box centred">
                <h2>Off-campus Accommodation Platform</h2>
                <p>Verified, Affordable, Convenience</p>
            </div>
            <div class="search-field">
                <div class="tabs-box">
                    <div class="tab-btn-box">
                        <ul class="tab-btns tab-buttons centred clearfix">
                        </ul>
                    </div>



</section>
<?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/frontend/home/banner.blade.php ENDPATH**/ ?>