<div class="sidebar-widget category-widget">
    <div class="widget-title">
        <h4>User Panel</h4>
    </div>
    <div class="widget-content">
        <ul class="category-list ">
<li><a href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-cog" aria-hidden="true"></i> Settings</a></li>
<li><a href="<?php echo e(route('user.wishlist')); ?>"><i class="fa fa-heart" aria-hidden="true"></i> Wishlist</a></li>
<li><a href="<?php echo e(route('user.change.password')); ?>"><i class="fa fa-key" aria-hidden="true"></i> Change Password </a></li>
<li><a href="<?php echo e(route('user.logout')); ?>"><i class="fa fa-chevron-circle-up" aria-hidden="true"></i> Logout </a></li>
        </ul>
    </div>
  </div>

<?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/frontend/dashboard/dashboard_sidebar.blade.php ENDPATH**/ ?>