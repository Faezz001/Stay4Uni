<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-4 border-top mt-4 bottom-0">
    <p class="text-muted mb-1 mb-md-0">Copyright © 2024 <a href="https://stay4uni.com" target="_blank">Stay4Uni</a>.</p>
  </footer>
<?php /**PATH D:\xampp\htdocs\Stay4Uni\stay4uni\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>