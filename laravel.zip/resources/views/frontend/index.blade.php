@extends('frontend.frontend_dashboard')
@section('main')

<!-- banner-section -->

<!-- banner-section end -->
@include('frontend.home.banner')
<!-- category-section -->
@include('frontend.home.category')
<!-- category-section end -->


<!-- feature-section -->
@include('frontend.home.feature')
<!-- feature-section end -->


<!-- video-section -->

<!-- video-section end -->


<!-- deals-section -->

<!-- deals-section end -->

@endsection
