@php
$ptype = App\Models\PropertyType::latest()->limit(5)->get();
@endphp



