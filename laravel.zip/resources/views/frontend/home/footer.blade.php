<footer class="main-footer">
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="inner-box clearfix" style="display: flex; justify-content: center; align-items: center; text-align: center;">
                <div class="copyright pull-left">
                    <p><a href="index.html">Stay4Uni</a> &copy; 2024 All Rights Reserved</p>
                </div>
            </div>
        </div>
    </div>
</footer>
